package Simulation;

import java.util.List;

/**
 * @author HugoPro
 * 
 * The Leafy Class.
 */
public class Leafy extends Treeable
{
	/** The state. */
	private String state;
	
	/** The time left. */
	private int timeLeft;
	
	/** The position. */
	private int position;
	
	/** The besides. */
	private List<Integer> besides;
	
	/** The matter. */
	private int matter; 
	
	/*
	 * GETTERS & SETTERS
	 */
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getState()
	 */
	public String getState(){return this.state;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setState(java.lang.String)
	 */
	public void setState(String state){this.state = state;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getTimeLeft()
	 */
	public int getTimeLeft(){return timeLeft;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setTimeLeft(int)
	 */
	public void setTimeLeft(int timeLeft){this.timeLeft = timeLeft;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getPosition()
	 */
	public int getPosition(){return position;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setPosition(int)
	 */
	public void setPosition(int position){this.position = position;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getBesides()
	 */
	public List<Integer> getBesides(){return this.besides;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setBesides(java.util.List)
	 */
	public void setBesides(List<Integer> besides){this.besides = besides;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getMatter()
	 */
	public int getMatter(){return matter;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setMatter(int)
	 */
	public void setMatter(int matter){this.matter = matter;}
	
	
	/*
	 * CONSTRUCTOR
	 */
	/**
	 * Instantiates a new leafy.
	 * 
	 * @since 1.0
	 */
	public Leafy()
	{
		this(0, 1);
	}
	
	/**
	 * Instantiates a new leafy.
	 *
	 * @param position the position
	 * @param matter the matter
	 * @since 1.0
	 */
	public Leafy(int position, int matter)
	{
		this.state = "Leafy";
		this.timeLeft = Constantes.leafyTime;
		this.position = position;
		this.besides = null;
		this.matter = matter;
	}
	
	
	/*
	 * METHODS
	 */
	/* (non-Javadoc)
	 * @see Simulation.Tree#transition(int)
	 */
	public Tree transition(int humidity)
	{
		return new Aflame(this.position, this.besides, this.matter);
	}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getNeighboursToBurn()
	 */
	public List<Integer> getNeighboursToBurn()
	{
		//this.besides if the fire has to be extends to trees besides, null in all other cases.
		return null;
	}
}
