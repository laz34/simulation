package Simulation;

import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;

/**
 * @author HugoPro
 * 
 * The ListenWind Class.
 */
public class ListenWind implements MouseListener
{
	/** The forest. */
	private Forest forest;
	
	/** The pan. */
	private JPanel pan;
	
	/**
	 * Instantiates a new listen wind.
	 *
	 * @param forest the forest
	 * @param pan the pan
	 * @since 1.0
	 */
	public ListenWind(Forest forest, JPanel pan)
	{
		this.forest = forest;
		this.pan = pan;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	public void mouseClicked(MouseEvent e)
	{
		if(this.forest.getPause() && !this.forest.isSparkNotSelectedYet())
		{
			Point location = ((PointerInfo) MouseInfo.getPointerInfo()).getLocation();
			int x = (location.x - this.pan.getLocationOnScreen().x)/10;
			int y = (location.y - this.pan.getLocationOnScreen().y)/10;
			System.out.println("point = "+x+"/"+y);
			// Place wind destination
			this.forest.calculateWind(x, y);
		}
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
	 */
	public void mouseEntered(MouseEvent e){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	public void mouseExited(MouseEvent e){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	public void mousePressed(MouseEvent e){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	public void mouseReleased(MouseEvent e){}
}
