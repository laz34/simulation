package Simulation;

import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;

/**
 * @author HugoPro
 * 
 * The ListenSparks Class.
 */
public class ListenSparks implements MouseListener
{
	/** The forest. */
	private Forest forest;
	
	/** The pan. */
	private JPanel pan;

	private int treeSizeOnScreenX;

	private int treeSizeOnScreenY;
	
	/**
	 * Instantiates a new listen sparks.
	 *
	 * @param forest the forest
	 * @param pan the pan
	 * @param treeSizeOnScreen 
	 * @param treeSizeOnScreenY 
	 * @since 1.0
	 */
	public ListenSparks(Forest forest, JPanel pan, int treeSizeOnScreenX, int treeSizeOnScreenY)
	{
		this.forest = forest;
		this.pan = pan;
		this.treeSizeOnScreenX = treeSizeOnScreenX;
		this.treeSizeOnScreenY = treeSizeOnScreenY;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	public void mouseReleased(MouseEvent arg0){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	public void mousePressed(MouseEvent arg0){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	public void mouseExited(MouseEvent arg0){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
	 */
	public void mouseEntered(MouseEvent arg0){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	public void mouseClicked(MouseEvent arg0)
	{
		Point location = ((PointerInfo) MouseInfo.getPointerInfo()).getLocation();
		int x = (location.x - this.pan.getLocationOnScreen().x)/treeSizeOnScreenX;
		int y = (location.y - this.pan.getLocationOnScreen().y)/treeSizeOnScreenY;
		System.out.println("point = "+x+"/"+y);
		// Add spark
		if(forest.addSpark((y*forest.getWidth())+x))
		{
			// Increment the selected sparks number if the tree is not fireproof
			Forest.incrementSparksSelectedThreadSafe(forest);
		}
	}
}
