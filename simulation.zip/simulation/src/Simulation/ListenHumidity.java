package Simulation;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JOptionPane;

/**
 * @author HugoPro
 * 
 * The ListenHumidity Class.
 */
public class ListenHumidity implements MouseListener
{
	/** The forest. */
	private Forest forest;
	
	/**
	 * Instantiates a new listen humidity.
	 *
	 * @param forest the forest
	 * @since 1.0
	 */
	public ListenHumidity(Forest forest)
	{
		this.forest = forest;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	public void mouseClicked(MouseEvent arg0)
	{
		// Pause the program if not paused
		if(!this.forest.getPause())
		{
			this.forest.setPause(true);
			this.forest.getForestFrame().getPauseButton().setText("Play");
		}
		// Stop drawing the panel while the message is display
		this.forest.setDontDraw(true);
		
		// Ask the wind's speed
		String inputValue = JOptionPane.showInputDialog("Humidity between 0 and 100%");
		while(inputValue == null || inputValue.isEmpty() || !inputValue.matches("[0-9]*") || (Integer.parseInt(inputValue))<0 || (Integer.parseInt(inputValue))>100)
	    {
			inputValue = JOptionPane.showInputDialog("Incorrect value. Humidity between 0 and 100%");
	    }
		int humidity = Integer.parseInt(inputValue);
		this.forest.setHumidity(humidity);
		this.forest.setDontDraw(false);
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
	 */
	public void mouseEntered(MouseEvent arg0){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	public void mouseExited(MouseEvent arg0){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	public void mousePressed(MouseEvent arg0){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	public void mouseReleased(MouseEvent arg0){}
}
