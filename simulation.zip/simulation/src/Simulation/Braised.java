package Simulation;

import java.util.List;

/**
 * @author HugoPro
 * 
 * The Braised Class.
 */
public class Braised extends Treeable
{
	/** The state. */
	private String state;
	
	/** The time left. */
	private int timeLeft;
	
	/** The position. */
	private int position;
	
	/** The besides. */
	private List<Integer> besides;
	
	/** The matter. */
	private int matter; 
	
	/*
	 * GETTERS & SETTERS
	 */
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getState()
	 */
	public String getState(){return this.state;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setState(java.lang.String)
	 */
	public void setState(String state){this.state = state;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getTimeLeft()
	 */
	public int getTimeLeft(){return timeLeft;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setTimeLeft(int)
	 */
	public void setTimeLeft(int timeLeft){this.timeLeft = timeLeft;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getPosition()
	 */
	public int getPosition(){return position;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setPosition(int)
	 */
	public void setPosition(int position){this.position = position;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getBesides()
	 */
	public List<Integer> getBesides(){return this.besides;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setBesides(java.util.List)
	 */
	public void setBesides(List<Integer> besides){this.besides = besides;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getMatter()
	 */
	public int getMatter(){return matter;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setMatter(int)
	 */
	public void setMatter(int matter){this.matter = matter;}
	
	
	/*
	 * CONSTRUCTOR
	 */
	/**
	 * Instantiates a new braised.
	 */
	public Braised()
	{
		this(0, null, 1);
	}
	
	/**
	 * Instantiates a new braised.
	 *
	 * @param position the position
	 * @param besides the besides
	 * @param matter the matter
	 */
	public Braised(int position, List<Integer> besides, int matter)
	{
		this.state = "Braised";
		this.timeLeft = Constantes.braisedTime;
		this.position = position;
		this.besides = besides;
		this.matter = matter;
	}
	
	
	/*
	 * METHODS
	 */
	/* (non-Javadoc)
	 * @see Simulation.Tree#transition(int)
	 */
	public Tree transition(int humidity)
	{
		this.timeLeft--;
		float hum = (float) (humidity/10);
		float inflammability = ((float) (this.matter/10));
		if((hum+this.timeLeft-inflammability) <= 0)
			return new Ashes(this.position, this.besides, this.matter);
		return this;
	}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getNeighboursToBurn()
	 */
	public List<Integer> getNeighboursToBurn()
	{
		//this.besides if the fire has to be extends to trees besides, null in all other cases.
		return null;
	}
}