package Simulation;

import java.util.List;

/**
 * @author HugoPro
 * 
 * The Tree Interface.
 */
public interface Tree
{
	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState();
	
	/**
	 * Sets the state.
	 *
	 * @param state the new state
	 */
	public void setState(String state);
	
	/**
	 * Gets the time left.
	 *
	 * @return the time left
	 */
	public int getTimeLeft();
	
	/**
	 * Sets the time left.
	 *
	 * @param timeLeft the new time left
	 */
	public void setTimeLeft(int timeLeft);
	
	/**
	 * Gets the position.
	 *
	 * @return the position
	 */
	public int getPosition();
	
	/**
	 * Sets the position.
	 *
	 * @param position the new position
	 */
	public void setPosition(int position);
	
	/**
	 * Gets the besides.
	 *
	 * @return the besides
	 */
	public List<Integer> getBesides();
	
	/**
	 * Sets the besides.
	 *
	 * @param besides the new besides
	 */
	public void setBesides(List<Integer> besides);
	
	/**
	 * Gets the matter.
	 *
	 * @return the matter
	 */
	public int getMatter();
	
	/**
	 * Sets the matter.
	 *
	 * @param matter the new matter
	 */
	public void setMatter(int matter);
	
	/**
	 * Transition.
	 *
	 * @param humidity the humidity
	 * @return the tree
	 */
	public Tree transition(int humidity);
	
	/**
	 * Gets the neighbors to burn.
	 *
	 * @return the neighbors to burn
	 */
	public List<Integer> getNeighboursToBurn();
}
