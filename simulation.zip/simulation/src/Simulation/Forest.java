package Simulation;

import java.awt.Frame;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import GenCol.entity;
import model.modeling.message;
import view.modeling.ViewableAtomic;

/**
 * @author HugoPro
 * 
 * The Forest Class.
 */
public class Forest extends ViewableAtomic
{
	private int counter;
	private int width;
	private int height;
	private List<Tree> map;
	private List<Tree> burning;
	private List<Tree> treesBurned;
	private Framet forestFrame;
	private Mapping mapping;
	private Frame frame;
	private File fileImage;
	private boolean sparkNotSelectedYet;
	private int sparksNumber;
	private int sparksSelected;
	private ListenSparks sparksPositionsListener;
	private boolean pause;
	private int targetArea;
	private int windDestination;
	private int windAngle;
	private int windSpeed;
	private int humidity;
	private boolean dontDraw;
	private boolean targetAreaOnFire;
	private int treeSizeOnScreenX;
	private int treeSizeOnScreenY;
	
	
	
	/*
	 * GETTERS & SETTERS
	 */
	public Framet getForestFrame(){return forestFrame;}
	public void setForestFrame(Framet forestFrame){this.forestFrame = forestFrame;}
	public int getWidth(){return this.width;}
	public int getHeight(){return this.height;}
	public boolean isSparkNotSelectedYet(){return this.sparkNotSelectedYet;}
	public int getSparksNumber(){return this.sparksNumber;}
	public int getSparksSelected(){return this.sparksSelected;}
	public void incrementSparksSelected(){this.sparksSelected++;}
	public static void incrementSparksSelectedThreadSafe(Forest f)
		{if(f.getSparksSelected() < f.getSparksNumber())
			f.incrementSparksSelected();}
	public boolean getPause(){return this.pause;}
	public void setPause(boolean pause){this.pause = pause;}
	public int getTargetArea(){return targetArea;}
	public void setTargetArea(int targetArea){this.targetArea = targetArea;}
	public int getWindDestination(){return this.windDestination;}
	public void setWindDestination(int windDestination){this.windDestination = windDestination;}
	public int getWindSpeed(){return windSpeed;}
	public void setWindSpeed(int windSpeed)
		{this.windSpeed = windSpeed;
		 this.forestFrame.getWindSpeed().setText("Wind Speed = "+windSpeed+" km/h");}
	public int getHumidity(){return humidity;}
	public void setHumidity(int humidity)
		{this.humidity = humidity;
		 this.forestFrame.getHumidity().setText("Humidity = "+humidity+"%");}
	public boolean isDontDraw(){return dontDraw;}
	public void setDontDraw(boolean dontDraw){this.dontDraw = dontDraw;}
	
	
	
	
	
	// FIRST CALL ON PROGRAM LOAD
	/*
	 * CONSTRUCTOR
	 */
	/**
	 * Instantiates a new forest.
	 * 
	 * @since 1.0
	 */
	public Forest()
	{
		addInport("in");
		addTestInput("in", new entity());
		sigma = 1;
		phase = "Ready";
		counter = -1;
		
		map = new ArrayList<Tree>();
		width = 0;
		height = 0;
		
		burning = new ArrayList<Tree>();
		
		init(0);
	}
	
	
	
	
	/*
	 * METHODS
	 */
	/**
	 * Initiates the forest.
	 *
	 * @param comeBack the come back
	 * @since 1.0
	 */
	public void init(int comeBack)
	{
		//Actions windows
		final JFileChooser fc = new JFileChooser();
		boolean closed = false;
		//While no map file is loaded keep asking what to do
		while(map.size()==0 && !closed)
		{
			if(comeBack==1)
			{
				mapping = new Mapping(fileImage, this);
				mapping.run();
				closed = true;
			}
			else
			{
				Object[] options = {"Select a map", "Add a new map"};
				int choice = JOptionPane.showOptionDialog(new Frame(), "Would you like to:", "Action", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
				
				//Select a map
				if(choice == JOptionPane.YES_OPTION)
				{
					System.out.println("choice : Select a map");
			        if(fc.showOpenDialog(fc) == JFileChooser.APPROVE_OPTION)
			        	readFile(fc.getSelectedFile());
				}
				//OR Add a new map
				else if(choice == JOptionPane.NO_OPTION)
				{
					//File selection
					if(fc.showOpenDialog(fc) == JFileChooser.APPROVE_OPTION)
					{
						fileImage = fc.getSelectedFile();
						//Display the mapping window
						mapping = new Mapping(fileImage, this);
						mapping.run();
						closed = true;
					}
				}
				//OR Close clicked
				else
				{
					int confirmClosing = JOptionPane.showConfirmDialog(frame, "Are you sure you want to cancel?", "Confirmation", JOptionPane.YES_NO_OPTION);
					//If confirmation is selected the program will close
					if(confirmClosing == JOptionPane.YES_OPTION)
						closed = true;
				}
			}
		}
		
		if(!closed)
		{
			//The map is loaded, the execution can begin normally after a deltext call
			message m = new message();
			m.add("Start Automaticaly");
			deltext(new Double(1), m);
		}
	}
	
	/* (non-Javadoc)
	 * @see model.modeling.atomic#initialize()
	 */
	public void initialize()
	{
		super.initialize();
	}
	
	/* (non-Javadoc)
	 * @see model.modeling.atomic#deltext(double, model.modeling.message)
	 */
	public void deltext(double e, message x)
	{
		Continue(e);
		
		//System.out.println("W = " +width+", H = "+height);
		if(x.getLength()>0)
		{
			//Display the simulating window
			forestFrame = new Framet(width, height);
			treeSizeOnScreenX = 1024/width;
			treeSizeOnScreenY = 512/height;
			this.forestFrame.setTreeSizeOnScreen(this.treeSizeOnScreenX, this.treeSizeOnScreenY);
			
			// Ask the user for random sparks or chosen sparks
			Object[] options = {"Random", "Chosen"};
			int n = JOptionPane.showOptionDialog(frame, "Sparks generation?", "Random or Chosen sparks", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
			this.sparkNotSelectedYet = true;
			if(n == JOptionPane.YES_NO_OPTION)
			{
				sparksNumber = (int) (Math.random()*(10-1)) + 1;
				for(int i=0; i<sparksNumber; i++){addSpark((int) (Math.random()*(map.size()-1)));}
				this.sparkNotSelectedYet = false;
				counter = 0;
			}
			
			// Initialize pause to true
			this.pause = true;
			// Initialize wind
			this.windDestination = ((this.height/2)*this.width)+(this.width/2);
			// Add pause button listener
			this.forestFrame.getPauseButton().addMouseListener(new ListenPause(this, this.forestFrame.getPauseButton()));
			// Add wind and target area listener
			this.forestFrame.getForestPanel().addMouseListener(new ListenWindAndTargetArea(this, this.forestFrame.getForestPanel(), this.treeSizeOnScreenX, this.treeSizeOnScreenY));
			// Add wind speed listener
			this.forestFrame.getWindSpeed().addMouseListener(new ListenWindSpeed(this));
			// Add humidity listener
			this.forestFrame.getHumidity().addMouseListener(new ListenHumidity(this));
		}
	}
	
	/* (non-Javadoc)
	 * @see model.modeling.atomic#deltint()
	 */
	public void deltint()
	{
		// If sparks have been initialized
		if(this.sparkNotSelectedYet)
		{
			// If sparks number is correct and >0
			if(this.sparksNumber <= 0)
			{
				// Ask how many sparks the user wants
				String inputValue = JOptionPane.showInputDialog("How many sparks do you want? (Integer between 0 and 10)");
				while(inputValue == null || inputValue.isEmpty() || !inputValue.matches("[0-9]*") || (Integer.parseInt(inputValue))<1 || (Integer.parseInt(inputValue))>10)
			    {
					inputValue = JOptionPane.showInputDialog("Incorrect value. How many sparks do you want? (Integer between 0 and 10)");
			    }
				this.sparksNumber = Integer.parseInt(inputValue);
				
				// Add click event
				sparksPositionsListener = new ListenSparks(this, this.forestFrame.getForestPanel(), this.treeSizeOnScreenX , this.treeSizeOnScreenY);
				this.forestFrame.getForestPanel().addMouseListener(sparksPositionsListener);
			}
			// If all sparks have been selected
			if(this.sparksSelected == this.sparksNumber)
			{
				this.forestFrame.getForestPanel().removeMouseListener(sparksPositionsListener);
				this.sparkNotSelectedYet = false;
				counter = 0;
			}
		}
		// If the simulation is running
		else if(!pause)
		{
			// If the simulation has begun
			if(counter >= 0)
				counter++;
			boolean setTargetAreaOnFire = false;
			treesBurned = new ArrayList<Tree>();
			for(int i=0; i<burning.size(); i++)
			{
				if(!targetAreaOnFire && burning.get(i).getPosition() == this.targetArea)
					setTargetAreaOnFire = true;
				Tree t = burning.get(i).transition(this.humidity);
				map.set(t.getPosition(), t);
				if(t.getState().equals("Ashes"))
				{
					burning.remove(i);
					i--;
				}
				else
				{
					burning.set(i, t);
					extendFire(t.getNeighboursToBurn(), t.getPosition());
				}
			}
			//Add new trees burned in the burning list
			for(Tree t : treesBurned){burning.add(t);}
			
			// If the target area is on fire
			if(setTargetAreaOnFire)
			{
				targetAreaOnFire = true;
				// Display message
				JOptionPane.showMessageDialog(new Frame(), "The target is on fire after "+this.counter+" steps.", "Target on fire", JOptionPane.WARNING_MESSAGE);
			}
			
			//If a message has been sent and nothing is still burning: stop
			if(burning.size()==0 && counter >= 0)
			{
				System.out.println("\nSimulation ended normaly after "+counter+" steps.");
				sigma = Double.POSITIVE_INFINITY;
			}
		}
		// If the wind has to be shown (when the simulation is initialize and on pause)
		if(!dontDraw)
		{
			if(!this.sparkNotSelectedYet && pause)
				this.forestFrame.draw(this.map, this.windDestination, this.targetArea);
			else
				this.forestFrame.draw(this.map, -1, -1);
		}
	}
	
	/**
	 * Adds the spark.
	 *
	 * @param sparkPosition the spark position
	 * @since 1.0
	 * @return true, if successful
	 */
	public boolean addSpark(int sparkPosition)
	{
		if(map.get(sparkPosition).getState().equals("Leafy"))
		{
			map.set(sparkPosition, map.get(sparkPosition).transition(this.humidity));
			burning.add(map.get(sparkPosition));
			return true;
		}
		return false;
	}
	
	/**
	 * Read file.
	 *
	 * @param file the file
	 * @since 1.0
	 */
	public void readFile(File file)
	{
		try
		{
			InputStream ips=new FileInputStream(file);
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String ligne;
			int cptLine = 0;
			boolean corrupted = false;
			while ((ligne=br.readLine())!=null)
			{
				String cases[] = ligne.split(" ");
				int cptNumber = 0;
				if((cptNumber = (fillMap(cases))) >= 0)
				{
					//Display "corrupted" message
					JOptionPane.showMessageDialog(new Frame(), "Your file is corrupted at line "+cptLine+" on the "+cptNumber+" number", "Corrupted file", JOptionPane.ERROR_MESSAGE);
					corrupted = true;
					map = new ArrayList<Tree>();
					width = 0;
					height = 0;
					break;
				}
				cptLine++;
			}
			br.close();
			//Display "empty" message
			if(map.size()==0 && !corrupted)
				JOptionPane.showMessageDialog(new Frame(), "Your file is empty!", "Empty file", JOptionPane.ERROR_MESSAGE);
			//Display the read file
			else if(!corrupted)
			{
				for(int i=0; i<map.size(); i++)
				{
					map.get(i).setBesides(getBesides(i, width, height));
				}
				System.out.println("The file has been loaded correctly.");
			}
		}
		catch(Exception e){System.out.println(e.toString());}
	}
	
	/**
	 * Fill map.
	 *
	 * @param cases the cases
	 * @since 1.0
	 * @return negative integer in case of failure
	 */
	private int fillMap(String[] cases)
	{
		int i = 0;
		try
		{
			if(cases.length != 0)
			{
				//Save the width if width is null
				if(width == 0)
					width = cases.length;
				//If the cases.length doesn't match the saved width the list is uncompleted, the file is corrupted 
				else if(width != cases.length)
					return cases.length;
				height++;
			}
			else
				return -1;
			for(i=0; i<cases.length; i++)
			{
				if(Integer.parseInt(cases[i]) == 0)
					map.add(new Fireproof(map.size()));
				else
					map.add(new Leafy(map.size(), Integer.parseInt(cases[i])));
				//System.out.print(Integer.parseInt(cases[i])+" ");
			}
			//System.out.println("");
		}
		catch(Exception e){System.out.println("\n"+e.toString());return i;}
		return -1;
	}
	
	/**
	 * Gets the trees beside (the 8 around) the current burning tree.
	 *
	 * @param position the position
	 * @param width the width
	 * @param height the height
	 * @since 1.0
	 * @return the list of trees beside
	 */
	private List<Integer> getBesides(int position, int width, int height)
	{
		List<Integer> besides = new ArrayList<Integer>();
		if(position >= width)//Pas sur la premiere Ligne
			besides.add(position-width);
		if(position < (width*(height-1)))//Pas sur la derniere Ligne
			besides.add(position+width);
		if(position%width != 0)//Pas sur la premiere colonne
			besides.add(position-1);
		if(position%width != (width-1))//Pas sur la derniere colonne
			besides.add(position+1);
		if(position >= width && position%width != 0)//Pas sur la premiere ligne ni la premiere colonne
			besides.add(position-width-1);
		if(position >= width && position%width != (width-1))//Pas sur la premiere ligne ni la derniere colonne
			besides.add(position-width+1);
		if(position < (width*(height-1)) && position%width != 0)//Pas sur la derniere ligne ni sur la premiere colonne
			besides.add(position+width-1);
		if(position < (width*(height-1)) && position%width != (width-1))//Pas sur la derniere ligne ni sur la derniere colonne
			besides.add(position+width+1);
		return besides;
	}
	
	/**
	 * Extend fire.
	 *
	 * @param neighboursToBurn the neighbors to burn
	 * @param firePosition the fire position
	 * @since 1.0
	 */
	private void extendFire(List<Integer> neighboursToBurn, int firePosition)
	{
		if(neighboursToBurn != null)
		{
			//For each neighbor, if the tree is in Leafy state: burn it
			for(int i=0; i<neighboursToBurn.size(); i++)
			{
				int treePosition = neighboursToBurn.get(i);
				if(toBurnAccordingToWind(firePosition, treePosition))
				{
					if(map.get(treePosition).getState().equals("Leafy"))
					{
						Tree t = map.get(treePosition).transition(this.humidity);
						//System.out.print(t.getPosition()+" -> ");
						map.set(treePosition, t);
						treesBurned.add(t);
					}
				}
			}
		}
	}
	
	/**
	 * To burn according to wind.
	 *
	 * @param firePosition the fire position
	 * @param treePosition the tree position
	 * @since 1.0
	 * @return true, if successful
	 */
	private boolean toBurnAccordingToWind(int firePosition, int treePosition)
	{
		// Wind Strength
		int windStrength = this.windSpeed;
		
		int fireCone = 0;
		// If the tree is after the fire in the list
		if(firePosition < treePosition)
		{
			// EST
			if(firePosition == (treePosition-1))
				fireCone = 180 - windStrength - (Math.min(Math.abs(this.windAngle), Math.abs(360-this.windAngle)));
			// SOUTH
			else if(firePosition == (treePosition-width))
			{
				if(this.windAngle > 270)
					fireCone = 180 - windStrength - (450 - this.windAngle);
				else
					fireCone = 180 - windStrength - Math.abs(90 - this.windAngle);
			}
			// SOUTH EST
			else if(treePosition == (firePosition+width+1))
			{
				if(this.windAngle > 225)
					fireCone = 180 - windStrength - (405 - this.windAngle);
				else
					fireCone = 180 - windStrength - Math.abs(45 - this.windAngle);
			}
			// SOUTH WEST
			else
			{
				if(this.windAngle > 315)
					fireCone = 180 - windStrength - (495 - this.windAngle);
				else
					fireCone = 180 - windStrength - Math.abs(135 - this.windAngle);
			}
		}
		// If the tree is before the fire in the list
		else if(firePosition > treePosition)
		{
			// WEST
			if(firePosition == (treePosition+1))
				fireCone = 180 - windStrength - Math.abs(180 - this.windAngle);
			// NORTH
			else if(treePosition == (firePosition-width))
			{
				if(this.windAngle < 90)
					fireCone = 180 - windStrength - (90 + this.windAngle);
				else
					fireCone = 180 - windStrength - Math.abs(this.windAngle-270);
			}
			// NORTH EST
			else if(treePosition == ((firePosition-width)+1))
			{
				if(this.windAngle < 135)
					fireCone = 180 - windStrength - (45 + this.windAngle);
				else
					fireCone = 180 - windStrength - Math.abs(this.windAngle-315);
			}
			// NORTH WEST
			else
			{
				if(this.windAngle < 45)
					fireCone = 180 - windStrength - (45 + this.windAngle);
				else
					fireCone = 180 - windStrength - Math.abs(this.windAngle-225);
			}
		}
		// -50 : negative or positive, /10 : between -10 and 10
		float near0 = (float) (((float) (fireCone-50))/10);
		// Sigmo�de : lot of chance, or very few
		float happend = (float) (100*(1/(1+(Math.exp(-near0)))));
		// Cast to int
		fireCone = 5*((int) happend);
		//int chance = 50;
		int chance = ((int) (Math.random()*100));
		if(fireCone >= chance)
			return true;
		return false;
	}
	
	/**
	 * Calculate wind.
	 *
	 * @param x the abscissa
	 * @param y the ordinate
	 * @since 1.0
	 */
	public void calculateWind(int x, int y)
	{
		this.windDestination = (y*this.width)+x;
		
		// Calculate angle in degrees between a vector i going from the center of the panel to the center of the left border of the panel 
		this.windAngle = 0;
		int op = y - height/2;
		int adj = x - width/2;
		
		if(adj != 0)
		{
			float tan = (float) op/adj;
			this.windAngle = (int) Math.toDegrees(Math.atan(Math.abs(tan)));
			if(op>0 && adj<0)
				this.windAngle = 180 - this.windAngle;
			else if(op<0 && adj<0)
				this.windAngle += 180;
			else if(op<0 && adj>0)
				this.windAngle = 360 - this.windAngle;
		}
		if(op == 0 && adj>0)
			this.windAngle = 0;
		else if(adj == 0 && op>0)
			this.windAngle = 90;
		else if(op == 0 && adj<0)
			this.windAngle = 180;
		else if(adj == 0 && op<0)
			this.windAngle = 270;
		System.out.println("Angle = "+ this.windAngle);
	}
	
	public void calculateTargetArea(int x, int y)
	{
		this.targetArea = (y*this.width)+x;
		this.targetAreaOnFire = false;
	}
}
