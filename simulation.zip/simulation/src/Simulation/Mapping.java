package Simulation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.AbstractButton;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * @author HugoPro
 * 
 * The Mapping Class.
 */
public class Mapping extends JFrame implements Runnable
{
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3056964168347721920L;
	
	/** The width. */
	private int width;
	
	/** The height. */
	private int height;
	
	/** The pic label. */
	private JLabel picLabel;
	
	/** The width matrice. */
	private int widthMatrice;
	
	/** The height matrice. */
	private int heightMatrice;
	
	/** The matrice. */
	private List<Integer> matrice;
	
	/** The pan. */
	private JPanel pan;
	
	/** The forest. */
	private Forest forest;
	
	/** The inflammability. */
	private int inflammability;

	private JLayeredPane lp;

	private int sizeW;

	private int sizeH;

	private int cursorSize;
	
	/**
	 * Instantiates a new mapping.
	 *
	 * @param image the image
	 * @param forest the forest
	 * @since 1.0
	 */
	public Mapping(File image, Forest forest)
	{
		this.forest = forest;
		
		//Load image
		picLabel = null;
		loadImage(image);
		
		//Get width and height and continue
		if(picLabel != null)
			init();
		else
		{
			JOptionPane.showMessageDialog(new Frame(), "Sorry, the selected file is not correct.", "Image Corrupted", JOptionPane.ERROR_MESSAGE);
			exitMapping(0);
		}
	}
	
	/**
	 * Load image.
	 *
	 * @param fileImage the file image
	 * @since 1.0
	 */
	private void loadImage(File fileImage)
	{
		ImageIcon myPicture = null;
		try
		{
			BufferedImage ima = ImageIO.read(fileImage);
			myPicture = new ImageIcon(ima);
			if(myPicture != null)
			{
				this.width = 1024;
				this.height = 512;
				
				Image img = myPicture.getImage();
				Image newimg = img.getScaledInstance(this.width, this.height, java.awt.Image.SCALE_FAST);
				myPicture = new ImageIcon(newimg);
				picLabel = new JLabel(myPicture);
			}
		}
		catch(Exception e){e.printStackTrace();}
	}

	/**
	 * Initiates the mapping.
	 * 
	 * @since 1.0
	 */
	private void init()
	{
		//Tools
		JButton coverageSize = new JButton("Change coverage");
		coverageSize.addMouseListener(new MouseListener()
		{
			public void mouseReleased(MouseEvent arg0){}
			public void mousePressed(MouseEvent arg0){}
			public void mouseExited(MouseEvent arg0){}
			public void mouseEntered(MouseEvent arg0){}
			public void mouseClicked(MouseEvent arg0)
			{
				//Exit and destroy everything but come back with the same file and ask for coverage size
				exitMapping(1);
			}
		});
		
		JButton save = new JButton("Save");
		save.setVerticalTextPosition(AbstractButton.CENTER);
		save.setHorizontalTextPosition(AbstractButton.LEADING);
		save.addMouseListener(new MouseListener()
		{
			public void mouseReleased(MouseEvent arg0){}
			public void mousePressed(MouseEvent arg0){}
			public void mouseExited(MouseEvent arg0){}
			public void mouseEntered(MouseEvent arg0){}
			public void mouseClicked(MouseEvent arg0)
			{
				//Save
				save();
				//Confirm
				JOptionPane.showMessageDialog(new Frame(), "The map has been saved correctly.", "Image saved", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		
		JLabel sliderLabel = new JLabel("Inflammability", JLabel.CENTER);
        sliderLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
	    JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 100, 0);
	    slider.setMajorTickSpacing(50);
	    slider.setMinorTickSpacing(50);
	    slider.setPaintTicks(true);
	    slider.setPaintLabels(true);
	    slider.addChangeListener(new ChangeListener()
	    {
			public void stateChanged(ChangeEvent e)
			{
				JSlider source = (JSlider) e.getSource();
				if (!source.getValueIsAdjusting())
			        setInflammability((int) source.getValue());
			}
		});
	    Box boxSlider = new Box(BoxLayout.Y_AXIS);
	    boxSlider.add(sliderLabel);
	    boxSlider.add(slider);
	    
	    JLabel cursorSizeLabel = new JLabel("Cursor size", JLabel.CENTER);
	    cursorSizeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
	    JSlider cursorSize = new JSlider(JSlider.HORIZONTAL, 1, 100, 1);
	    cursorSize.setMajorTickSpacing(49);
	    cursorSize.setMinorTickSpacing(49);
	    cursorSize.setPaintTicks(true);
	    cursorSize.setPaintLabels(true);
	    cursorSize.addChangeListener(new ChangeListener()
	    {
			public void stateChanged(ChangeEvent e)
			{
				JSlider source = (JSlider) e.getSource();
				if (!source.getValueIsAdjusting())
			        setCursorSize((int) source.getValue());
			}
		});
	    Box boxSliderCursor = new Box(BoxLayout.Y_AXIS);
	    boxSliderCursor.add(cursorSizeLabel);
	    boxSliderCursor.add(cursorSize);
		
		//Panel tools
		JPanel tools = new JPanel();
	    Dimension dim = new Dimension(800, 70);
	    tools.setPreferredSize(dim);
	    tools.setMaximumSize(dim);
	    tools.setMinimumSize(dim);
	    tools.setBackground(Color.WHITE);
	    tools.add(coverageSize);
	    tools.add(save);
	    tools.add(boxSlider);
	    tools.add(boxSliderCursor);
	    tools.validate();
	    
		//Panel image and coverage
	    lp = new JLayeredPane();
	    
	    loadCoverage();
	    
	    pan = new JPanel();
	    pan.setLayout(new BorderLayout());
	    dim = new Dimension(width, height);
	    pan.setPreferredSize(dim);
	    pan.setMaximumSize(dim);
	    pan.setMinimumSize(dim);
	    pan.validate();
	    //pan.setVisible(true);
	    pan.add(lp);
	    ListenMapping lmapping = new ListenMapping(this, pan);
	    pan.addMouseListener(lmapping);
	    pan.addMouseMotionListener(lmapping);
	    
	    //Box (for the center alignment)
	    Box box = new Box(BoxLayout.Y_AXIS);
        box.add(tools);
        box.add(pan);
        
        //Frame
	    this.add(box);
	    this.setSize(new Dimension(1200, 620));
	    this.setMinimumSize(this.getMinimumSize());
	    this.setLocationRelativeTo(null);
	    this.setResizable(false);
	    //Allow the user to close the mapping window without having to restart the program
	    this.addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){exitMapping(0);}});
	    
	    this.setVisible(true);
	    this.toFront();
	}
	
	/**
	 * Load coverage.
	 *
	 * @since 1.0
	 */
	private void loadCoverage()
	{
		JPanel fond = new JPanel();
	    fond.setBounds(0, -5, width, height+5);
	    fond.add(picLabel);
		
		//Ask for the matrice's size
	    String s = "";
	    while(s == null || s.length() == 0)
	    {
	    	Object[] possibilities = {"16x16", "32x32", "64x64", "128x128", "256x256", "512x512"};
		    s = (String)JOptionPane.showInputDialog(new Frame(), "Select the coverage's resolution:\n", "Coverage's resolution", JOptionPane.PLAIN_MESSAGE, null, possibilities, "128x128");
		}
	    if(s.equals("16x16")){widthMatrice = 16; heightMatrice = 16;}
	    else if(s.equals("32x32")){widthMatrice = 32; heightMatrice = 32;}
	    else if(s.equals("64x64")){widthMatrice = 64; heightMatrice = 64;}
	    else if(s.equals("128x128")){widthMatrice = 128; heightMatrice = 128;}
	    else if(s.equals("256x256")){widthMatrice = 256; heightMatrice = 256;}
	    else if(s.equals("512x512")){widthMatrice = 512; heightMatrice = 512;}
	    
		matrice = new ArrayList<Integer>();
	    sizeW = width/widthMatrice;
	    sizeH = height/heightMatrice;
	    System.out.println("sizeW="+sizeW+" sizeH="+sizeH);
	    for(int h=0; h<widthMatrice; h++)
	    {
		    for(int w=0; w<widthMatrice; w++)
		    {
		    	matrice.add(1);
		    }
	    }
	    lp.add(fond);
	}

	/**
	 * Exit mapping.
	 *
	 * @param comeBack the come back
	 * @since 1.0
	 */
	private void exitMapping(int comeBack)
	{
		this.setVisible(false);
		this.dispose();
		this.forest.init(comeBack);
	}
	
	/**
	 * Save the matrix
	 * 
	 * @since 1.0
	 */
	private void save()
	{
		//File chooser
		JFileChooser fc = new JFileChooser();
		if(fc.showSaveDialog(fc) == JFileChooser.APPROVE_OPTION)
        	writeFile(fc.getSelectedFile());
	}
	
	/**
	 * Write file.
	 *
	 * @param selectedFile the selected file
	 * @since 1.0
	 */
	private void writeFile(File selectedFile)
	{
		try
		{
			// Create file
			FileWriter fstream = new FileWriter(selectedFile);
			BufferedWriter out = new BufferedWriter(fstream);
			for(int i=0; i<heightMatrice; i++)
			{
				for(int j=0; j<widthMatrice; j++)
				{
					out.write(matrice.get(i*widthMatrice+j)+" ");
				}
				out.write("\r\n");
			}
			out.close();
		}
		catch (Exception e){System.err.println("Error: " + e.getMessage());}
	}
	

	/**
	 * Sets the inflammability.
	 *
	 * @param value the new inflammability
	 * @since 1.0
	 */
	protected void setInflammability(int value)
	{
		this.inflammability = value;
	}
	
	protected void setCursorSize(int value)
	{
		this.cursorSize = value;
	}
	
	/**
	 * Sets the matrix.
	 *
	 * @param x the x
	 * @param y the y
	 * @param e the e
	 * @since 1.0
	 */
	public void setMatrice(int x, int y)
	{
		if(x >= 0 && x <= (widthMatrice*sizeW))
		{
			Graphics g = pan.getGraphics();
			int x1 = (((y-this.cursorSize)/sizeH)*widthMatrice)+((x-this.cursorSize)/sizeW);
			int x2 = (((y-this.cursorSize)/sizeH)*widthMatrice)+((x+this.cursorSize)/sizeW);
			if((y-this.cursorSize) <= 0)
			{
				if((x-this.cursorSize) <= 0)
					x1 = 0;
				else
					x1 = ((x-this.cursorSize)/sizeW);
				if((x+this.cursorSize) >= (widthMatrice*sizeW))
					x2 = (widthMatrice-1);
				else
					x2 = ((x+this.cursorSize)/sizeW);
			}
			else
			{
				if((x-this.cursorSize) <= 0)
					x1 = (((y-this.cursorSize)/sizeH)*widthMatrice);
				if((x+this.cursorSize) >= (widthMatrice*sizeW))
					x2 = (((y-this.cursorSize)/sizeH)*widthMatrice)+(widthMatrice-1);
			}
			int x4 = (((y+this.cursorSize)/sizeH)*widthMatrice)+((x+this.cursorSize)/sizeW);
			while(x1 <= x4 && x1 < matrice.size())
			{
				int i = x1;
				while(i <= x2)
				{
					matrice.set(i, this.inflammability);
					
					int Xcoord = i%widthMatrice;
					int Ycoord = i/heightMatrice;
					Xcoord *= sizeW;
					Ycoord *= sizeH;
					if(this.inflammability==0)
						g.setColor(new Color(0,0,255,255));
					else
						g.setColor(new Color(0,100+this.inflammability,0,255));
					g.fillRect(Xcoord, Ycoord, sizeW, sizeH);
					i++;
				}
				x1 += widthMatrice;
				x2 += widthMatrice;
			}
		}
	}
	
	public void paintIt()
	{
		Graphics g = pan.getGraphics();
		int x, y;
		for(int i=0; i<matrice.size(); i++)
		{
			x = i%widthMatrice;
			y = i/heightMatrice;
			x *= sizeW;
			y *= sizeH;
			if(this.matrice.get(i)==0)
				g.setColor(new Color(0,0,255,100));
			else
				g.setColor(new Color(0,255,0,100+this.matrice.get(i)));
			g.fillRect(x, y, sizeW, sizeH);
		}
	}
	
	public void paint(Graphics g)
	{
		super.paintComponents(g);
		super.paint(g);
		if(matrice != null)
	    	paintIt();
	}
	public void repaint(Graphics g)
	{
		super.paintComponents(g);
		super.paint(g);
		if(matrice != null)
	    	paintIt();
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run(){}
	
	
}