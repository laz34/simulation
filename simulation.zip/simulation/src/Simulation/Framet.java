package Simulation;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.List;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @author HugoPro
 * 
 * The Framet Class.
 */
public class Framet extends JFrame
{
	private static final long serialVersionUID = -530911687797179263L;
	
	/** The width. */
	private int largeur;
	
	/** The height. */
	private int hauteur;
	
	/** The pan. */
	private JPanel pan;
	
	/** The pause. */
	private JButton pause;
	
	/** The wind speed. */
	private JButton windSpeed;
	
	/** The humidity. */
	private JButton humidity;
	
	/** The map. */
	private List<Tree> map;
	
	/** The wind destination. */
	private int windDestination;

	private int targetArea;

	private int treeSizeOnScreenX;

	private int treeSizeOnScreenY;
	
	/** The refreshing. */
	private static boolean refreshing;
	
	
	
	/*
	 * GETTERS & SETTERS
	 */
	/**
	 * Gets the forest panel.
	 *
	 * @return the forest panel
	 */
	public JPanel getForestPanel(){return this.pan;}
	
	/**
	 * Gets the pause button.
	 *
	 * @return the pause button
	 */
	public JButton getPauseButton(){return this.pause;}
	
	/**
	 * Gets the wind speed.
	 *
	 * @return the wind speed
	 */
	public JButton getWindSpeed(){return this.windSpeed;}
	
	/**
	 * Gets the humidity.
	 *
	 * @return the humidity
	 */
	public JButton getHumidity(){return humidity;}
	
	
	
	/*
	 * CONSTRUCTOR
	 */
	/**
	 * Instantiates a new frame.
	 *
	 * @param largeur the width
	 * @param hauteur the height
	 * @since 1.0
	 */
	public Framet(int largeur, int hauteur)
	{
		this.setTitle("Forest");
		this.largeur = largeur;
		this.hauteur = hauteur;
		refreshing = false;
		
		//Panel
	    pan = new JPanel();
	    Dimension dim = new Dimension(1024, 512);
	    pan.setPreferredSize(dim);
	    pan.setMaximumSize(dim);
	    pan.setMinimumSize(dim);
	    pan.setBackground(Color.WHITE);
	    pan.validate();
	    
	    // Pause button
        pause = new JButton();
        // Wind Speed
        windSpeed = new JButton("Wind Speed = 0 km/h");
        // Humidity
        humidity = new JButton("Humidity = 0%");
        // Horizontal alignment
        Box buttonsBox = Box.createHorizontalBox();
        buttonsBox.add(pause);
        buttonsBox.add(windSpeed);
        buttonsBox.add(humidity);
        
	    //Box (for the center alignment)
	    Box box = new Box(BoxLayout.Y_AXIS);
        box.add(Box.createVerticalGlue());
        box.add(buttonsBox);
        box.add(pan);
        box.add(Box.createVerticalGlue());
        
        //Frame
	    this.add(box);
	    //this.setLocationRelativeTo(null);
	    this.setSize(new Dimension(1224, 612));
	    this.setMinimumSize(this.getMinimumSize());
	    this.setResizable(false);
	    
	    //On mouse move
	    this.addMouseMotionListener(new MouseMotionListener()
	    {
			public void mouseMoved(MouseEvent arg0){draw(map, windDestination, targetArea);}
			public void mouseDragged(MouseEvent arg0){draw(map, windDestination, targetArea);}
		});
	    this.setVisible(false);
	}
	
	/**
	 * Not refreshing.
	 *
	 * @since 1.0
	 * @return true, if successful
	 */
	public static boolean notRefreshing()
	{
		if(refreshing)
			return false;
		refreshing = true;
		return true;
	}
	
	/**
	 * Draw.
	 *
	 * @param map the map
	 * @param showWind the show wind
	 * @since 1.0
	 */
	public void draw(List<Tree> map, int showWind, int targetArea)
	{
		if(map != null && notRefreshing())
		{
			this.windDestination = showWind;
			this.targetArea = targetArea;
			this.setVisible(true);
			this.map = map;
			Graphics g = pan.getGraphics();
			String state = "";
			int x, y;
			for(int i=0; i<map.size(); i++)
			{
				x = i%largeur;
				y = i/largeur;
				x *= this.treeSizeOnScreenX;
				y *= this.treeSizeOnScreenY;
				if(showWind<0 || (showWind>=0 && !onWindLocation(i) && i != targetArea))
				{
					state = map.get(i).getState();
					if(state.equals("Leafy"))
						g.setColor(new Color(map.get(i).getMatter()+50,255,map.get(i).getMatter()+50));
					else if(state.equals("Aflame"))
						g.setColor(Color.decode("#ac4e00"));
					else if(state.equals("Fired"))
						g.setColor(Color.yellow);
					else if(state.equals("Braised"))
						g.setColor(Color.red);
					else if(state.equals("Fireproof"))
						g.setColor(Color.blue);
					else
						g.setColor(Color.gray);
					
					g.fillRect(x, y, this.treeSizeOnScreenX, this.treeSizeOnScreenY);
				}
				// If target area
				else if(showWind>=0 && i == targetArea)
				{
					g.setColor(Color.black);
					g.fillRect(x, y, this.treeSizeOnScreenX, this.treeSizeOnScreenY);
				}
				// If wind
				else if(showWind>=0)
				{
					g.setColor(Color.white);
					g.fillRect(x, y, this.treeSizeOnScreenX, this.treeSizeOnScreenY);
				}
			}
			refreshing = false;
		}
	}
	
	/**
	 * On wind location.
	 *
	 * @param i the i
	 * @since 1.0
	 * @return true, if successful
	 */
	private boolean onWindLocation(int i)
	{
		if(i%largeur == largeur/2 && i/largeur == hauteur/2)
			return true;
		if(i == this.windDestination)
			return true;
		return false;
	}

	public void setTreeSizeOnScreen(int treeSizeOnScreenX, int treeSizeOnScreenY)
	{
		this.treeSizeOnScreenX = treeSizeOnScreenX;
		this.treeSizeOnScreenY = treeSizeOnScreenY;
	}
}