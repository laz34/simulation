package Simulation;

import java.util.List;

/**
 * @author HugoPro
 * 
 * The Ashes Class.
 */
public class Ashes extends Treeable
{
	/** The state. */
	private String state;
	
	/** The time left. */
	private int timeLeft;
	
	/** The position. */
	private int position;
	
	/** The besides. */
	private List<Integer> besides;
	
	/** The matter. */
	private int matter; 
	
	/*
	 * GETTERS & SETTERS
	 */
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getState()
	 */
	public String getState(){return this.state;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setState(java.lang.String)
	 */
	public void setState(String state){this.state = state;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getTimeLeft()
	 */
	public int getTimeLeft(){return timeLeft;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setTimeLeft(int)
	 */
	public void setTimeLeft(int timeLeft){this.timeLeft = timeLeft;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getPosition()
	 */
	public int getPosition(){return position;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setPosition(int)
	 */
	public void setPosition(int position){this.position = position;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getBesides()
	 */
	public List<Integer> getBesides(){return this.besides;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setBesides(java.util.List)
	 */
	public void setBesides(List<Integer> besides){this.besides = besides;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getMatter()
	 */
	public int getMatter(){return matter;}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#setMatter(int)
	 */
	public void setMatter(int matter){this.matter = matter;}
	
	
	/*
	 * CONSTRUCTOR
	 */
	/**
	 * Instantiates a new ashes.
	 * 
	 * @since 1.0
	 */
	public Ashes()
	{
		this(0, null, 1);
	}
	
	/**
	 * Instantiates a new ashes.
	 *
	 * @param position the position
	 * @param besides the besides
	 * @param matter the matter
	 * @since 1.0
	 */
	public Ashes(int position, List<Integer> besides, int matter)
	{
		this.state = "Ashes";
		this.timeLeft = Constantes.ashesTime;
		this.position = position;
		this.besides = besides;
		this.matter = matter;
	}
	
	
	/*
	 * METHODS
	 */
	/* (non-Javadoc)
	 * @see Simulation.Tree#transition(int)
	 */
	public Tree transition(int humidity)
	{
		return this;
	}
	
	/* (non-Javadoc)
	 * @see Simulation.Treeable#getNeighboursToBurn()
	 */
	public List<Integer> getNeighboursToBurn()
	{
		//this.besides if the fire has to be extends to trees besides, null in all other cases.
		return null;
	}
}