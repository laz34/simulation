package Simulation;

/**
 * @author HugoPro
 * 
 * The Constantes Class.
 */
public class Constantes
{
	/** The leafy time. */
	public static int leafyTime = -1;
	
	/** The aflame time. */
	public static int aflameTime = 1;
	
	/** The fired time. */
	public static int firedTime = 70;
	
	/** The braised time. */
	public static int braisedTime = 23;
	
	/** The ashes time. */
	public static int ashesTime = -1;
	
	/** The fireproof time. */
	public static int fireproofTime = -1;
}
