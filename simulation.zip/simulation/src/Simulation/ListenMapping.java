package Simulation;

import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 * @author HugoPro
 * 
 * The ListenMapping Class.
 */
public class ListenMapping implements MouseListener, MouseMotionListener
{
	/** The mapping. */
	private Mapping mapping;
	private JPanel pan;
	
	public ListenMapping(Mapping mapping, JPanel pan)
	{
		this.mapping = mapping;
		this.pan = pan;
	}
	public void mouseReleased(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseClicked(MouseEvent e)
	{
		if(SwingUtilities.isLeftMouseButton(e))
		{
			Point location = ((PointerInfo) MouseInfo.getPointerInfo()).getLocation();
			int x = (location.x - this.pan.getLocationOnScreen().x);
			int y = (location.y - this.pan.getLocationOnScreen().y);
			this.mapping.setMatrice(x, y);
		}
		else
			this.mapping.paint(this.mapping.getGraphics());
	}
	
	public void mouseDragged(MouseEvent arg0)
	{
		Point location = ((PointerInfo) MouseInfo.getPointerInfo()).getLocation();
		int x = (location.x - this.pan.getLocationOnScreen().x);
		int y = (location.y - this.pan.getLocationOnScreen().y);
		this.mapping.setMatrice(x, y);
	}
	public void mouseMoved(MouseEvent arg0){}
}
