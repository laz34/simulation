package Simulation;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;

/**
 * @author HugoPro
 * 
 * The ListenPause Class.
 */
public class ListenPause implements MouseListener
{
	/** The forest. */
	private Forest forest;
	
	/** The pause button. */
	private JButton pauseButton;
	
	/**
	 * Instantiates a new listen pause.
	 *
	 * @param forest the forest
	 * @param pauseButton the pause button
	 * @since 1.0
	 */
	public ListenPause(Forest forest, JButton pauseButton)
	{
		this.forest = forest;
		this.pauseButton = pauseButton;
		this.pauseButton.setText("Play");
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	public void mouseClicked(MouseEvent e)
	{
		this.forest.setPause(!this.forest.getPause());
		if(this.forest.getPause())
			this.pauseButton.setText("Play");
		else
			this.pauseButton.setText("Pause");
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
	 */
	public void mouseEntered(MouseEvent e){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	public void mouseExited(MouseEvent e){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	public void mousePressed(MouseEvent e){}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	public void mouseReleased(MouseEvent e){}
}
